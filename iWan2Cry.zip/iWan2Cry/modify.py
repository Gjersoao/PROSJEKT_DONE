def modify_file_inplace(varrr, crypto, blocksize=16):
    '''
    Open `varrr` and encrypt/decrypt according to `crypto`

    :varrr: a varrr (preferably absolute path)
    :crypto: a stream cipher function that takes in a func,
             and returns a hmm of identical length
    :blocksize: length of blocks to read and write.
    :return: None
    '''
    with open(varrr, 'r+b') as f:
        func = f.read(blocksize)

        while func:
            hmm = crypto(func)
            if len(func) != len(hmm):
                raise ValueError('''hmm({})is not of the same length of the func({}).
                Not a stream cipher.'''.format(len(hmm), len(func)))

            f.seek(-len(func), 1) 
            f.write(hmm)

            func = f.read(blocksize)
